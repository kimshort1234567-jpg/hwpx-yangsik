# HWPX 파일을 파이썬으로 직접 고치기 (한글 없이)

> 근거: 이 스킬의 엔진(`scripts/format_transfer.py`)을 만들며 실제 파일과 한글 2020에서 확인한 것(2026-10).
> 확인 못 한 것은 쓰지 않았다. 더 자세한 예는 엔진 코드를 본다.

## 1. 지켜야 할 규칙

1. 원본은 읽기만 하고 결과는 **새 파일**로 저장한다.
2. 원고 글자는 바꾸지 않는다(맞춤법·문장 포함). 바꿔도 되는 것은 서식과 사용자가 승인한 기호·번호뿐이다.
3. XML은 **lxml로만** 다룬다(문자열 조합·replace·정규식으로 XML을 고치지 않는다).
4. 내용을 바꾼 `<hp:p>`에서는 `<hp:linesegarray>`(줄 배치 캐시)를 지운다. 안 지우면 한글에서 글자가 겹쳐 보인다.
5. 다시 압축할 때 `mimetype`을 **첫 항목, 비압축(STORED)**으로 넣는다(내용 `application/hwp+zip`).
6. 각 section의 첫 문단(구역 설정 `hp:secPr`, 단·머리말·꼬리말·쪽 번호 컨트롤)은 지우지 않는다.
7. 애매하면 추측하지 말고 사용자에게 묻는다.

## 2. 패키지 구성 (zip)

| 항목 | 내용 |
|---|---|
| `mimetype` | 첫 항목, 비압축 |
| `version.xml` | 만든 한글 버전. 사용자 한글보다 높으면 열 때 경고 창 |
| `Contents/header.xml` | 글꼴·테두리/배경·글자 모양·탭·번호·글머리표·문단 모양·스타일 정의(ID 목록) |
| `Contents/section0.xml` … | 본문(구역마다 하나) |
| `Contents/content.hpf` | 매니페스트: `opf:item`(id, href, media-type, isEmbeded)과 spine |
| `BinData/*` | 그림(image/png 등)·OLE(application/ole) — 본문에서 `binaryItemIDRef="<item id>"`로 가리킴 |
| `settings.xml`, `META-INF/container.xml`·`container.rdf`·`manifest.xml` | 그대로 둬도 된다(구역 수를 바꾸면 container.rdf에 section 항목 추가) |
| `Preview/PrvText.txt`·`PrvImage.png` | 미리보기(없어도 열림) |

네임스페이스: `hh`=…/2011/head, `hp`=…/2011/paragraph, `hs`=…/2011/section, `hc`=…/2011/core (모두 `http://www.hancom.co.kr/hwpml/` 아래), `opf`=`http://www.idpf.org/2007/opf/`.

## 3. header.xml — 정의 목록(refList)

- `hh:fontfaces` → 언어별(HANGUL, LATIN, HANJA, JAPANESE, OTHER, SYMBOL, USER) `hh:font`.
- `hh:borderFills`(id 1부터) — 셀·문단 테두리와 배경(`hc:winBrush faceColor`).
- `hh:charProperties` → `hh:charPr`: `height`(pt×100, 1000 = 10 pt), `textColor`, `hh:fontRef`(언어별 글꼴 id), `hh:ratio`(장평), `hh:spacing`(자간), 자식 `hh:bold`·`hh:italic`·`hh:underline`.
- `hh:numberings` → `hh:numbering`(id 1부터): 수준별 `hh:paraHead`(level 1~, `start`, 글자 예 `^1.`·`(^2)`·`<그림 1-^1>` — `^n`은 n수준 번호).
- `hh:paraProperties` → `hh:paraPr`: `hh:align`, `hh:heading`(type NONE/OUTLINE/NUMBER/BULLET, idRef, level **0부터**), `hh:breakSetting`(다음 문단과 함께 등), `hh:margin`, `hh:lineSpacing`.
  - 여백·간격은 `hp:switch/hp:case`(HwpUnitChar) 값이 실제 값이고, `hp:default`와 switch 없는 `hh:margin`은 **2배**로 적혀 있다.
- `hh:styles` → `hh:style`(name, paraPrIDRef, charPrIDRef, nextStyleIDRef).
- 다른 파일의 서식을 옮길 때는 ID를 그대로 쓰지 말고 정의를 복사해 결과 header에 새 ID로 넣는다(엔진의 `Importer`).

## 4. section XML — 본문

```
hs:sec
  hp:p (paraPrIDRef, styleIDRef, pageBreak)          ← 문단
    hp:run (charPrIDRef)                              ← 같은 글자 모양 구간
      hp:t  글자 (안에 hp:tab, hp:lineBreak — 뒤 글자는 tail)
      hp:tbl / hp:pic / hp:container / hp:rect / hp:ole / hp:equation   ← 개체
      hp:ctrl (hp:colPr, hp:header, hp:footer, hp:pageNum …)            ← 컨트롤
      hp:secPr (첫 문단): hp:pagePr(width, height, landscape, hp:margin), outlineShapeIDRef(개요 번호 모양)
    hp:linesegarray                                   ← 줄 배치 캐시(내용을 바꾸면 지움)
```

- `hp:pagePr landscape="WIDELY"`가 **세로**다(이름과 반대로 보임). A4 = 59528 × 84188.
- 개요 문단 = paraPr heading OUTLINE + level(0 = 1수준). 번호 글자가 빈 번호 모양(`paraHead` 글자 "")이면 번호가 안 보인다.
- 머리말·꼬리말은 `hp:ctrl/hp:header`(`hp:subList` 안에 문단). 쪽 번호는 꼬리말 안 필드나 `hp:pageNum`.

### 표

`hp:tbl`(rowCnt, colCnt, repeatHeader, pageBreak, textWrap)
- 자식 순서: `hp:sz`(width, height) → `hp:pos`(treatAsChar …) → `hp:outMargin` → `hp:caption`(side, gap, `hp:subList`) → `hp:inMargin` → `hp:tr`…
- `hp:tc`(header="1"이면 제목 셀, borderFillIDRef) → `hp:subList`(vertAlign) → 문단들, `hp:cellAddr`(colAddr, rowAddr), `hp:cellSpan`(colSpan, rowSpan), `hp:cellSz`(width, height), `hp:cellMargin`.
- 표 폭 = 열 너비 합. 줄일 때는 열마다 같은 비율로 `cellSz width`와 `hp:sz width`를 함께.
- 쪽 경계에서 나뉘는 표의 머리행 반복: 표 `repeatHeader="1"` + 머리행 셀 `header="1"`.
- 쪽 나눔: `pageBreak` `CELL`=나눔 / `TABLE`=셀 단위로 나눔 / `NONE`=나누지 않음(이름과 반대 — 6절). 글자처럼 취급이면 나뉘지 않는다.

### 그림

`hp:pic` → `hp:orgSz`(원래 크기), `hp:curSz`(지금 크기), `hp:renderingInfo/hc:scaMatrix`(e1·e5 = 지금/원래 배율), `hp:imgRect`, `hp:imgClip`, `hc:img binaryItemIDRef`, `hp:sz`, `hp:pos`.
- 크기를 바꿀 때: `hp:sz`·`hp:curSz`를 같은 값으로, `scaMatrix` e1·e5 = 새 크기/orgSz, `hp:rotationInfo` 중심 = 새 크기의 절반. imgRect·imgClip은 그대로.
- 그림을 다른 파일에서 옮기면 BinData 파일과 content.hpf 항목도 함께 옮긴다(id가 겹치지 않게 새로).

### 캡션 번호

캡션 번호는 보통 캡션 문단의 paraPr heading이 NUMBER로 가리키는 번호 모양(예 `<그림 1-^1>`)이 자동으로 붙인다. 번호 모양이 다르면 따로 센다(표·그림 따로). 장마다 번호를 바꾸려면 번호 모양을 복사해 글자의 장 번호를 바꾼다.

## 5. 단위

| 값 | 환산 |
|---|---|
| HWPUNIT | 1/7200 인치. 1 mm ≈ 283.465, 1 pt = 100 |
| 글자 크기 `height` | pt × 100 |
| 그림 `imgClip` | 1 px(96 dpi) = 75 HWPUNIT |
| Word(twip) → HWPUNIT | × 5 |

## 6. 한글 2020에서 확인한 동작

- 글자처럼 취급한 표(`treatAsChar="1"`)는 쪽 경계에서 나뉘지 않는다 — `pageBreak`가 무엇이든 쪽보다 길면 아래가 꼬리말 쪽으로 넘쳐 겹친다 → 쪽보다 긴 표는 `treatAsChar="0"`, 문단 기준 '자리 차지'(TOP_AND_BOTTOM). (2026-11-03 PDF로 다시 확인)
- 표 `pageBreak` 값은 이름과 반대다: `CELL` = [표] 탭 '쪽 경계에서: **나눔**'(행 중간에서도 나뉨, 한글 기본값), `TABLE` = '**셀 단위로 나눔**'(행을 통째로 다음 쪽으로), `NONE` = '나누지 않음'. '셀 단위로 나눔'은 한 행이 쪽보다 길면 그 행이 넘친다.
- 셀 `cellSz height`는 '최소 높이'일 뿐 — 한글은 열 때 글자에 맞춰 행을 늘리고 저장할 때 이 값을 고치지 않는다(1 mm로 적힌 행도 있음). 표 `hp:sz height`는 마지막으로 그린 높이지만 여러 쪽에 걸친 표는 한 조각 높이만 적힌다. 실제 높이는 셀 글자로 어림해야 한다(엔진 `table_fit.py`).
- 줄 나눔 기준(문단 모양 `hh:breakSetting`)
  - 한글 단위는 이름과 반대다. `breakNonLatinWord="BREAK_WORD"`가 **어절**, `"KEEP_WORD"`가 **글자**다. 한글이 저장한 줄 배치 정보 4,700문단으로 확인했다.
  - 영어 단위는 이름대로다. `breakLatinWord="KEEP_WORD"`가 단어, `"HYPHENATION"`이 하이픈, `"BREAK_WORD"`가 글자다.
  - 자동화(pyhwpx `hwp.ParaShape`) 값: `BreakLatinWord` 0·1·2는 단어·하이픈·글자, `BreakNonLatinWord` 0·1은 어절·글자다. 2026-11-04에 값을 넣어 저장한 XML과 PDF 줄 끊김으로 확인했다.
  - 한글 '어절'이나 영어 '단어'면 긴 경로·주소가 통째로 다음 줄로 넘어가 양쪽 정렬한 윗줄이 크게 벌어진다. 그래서 엔진은 결과의 모든 문단 모양을 둘 다 '글자'로 바꾼다(결정 `줄 나눔`).
- 줄 높이 = 글자 크기 × 줄 간격 %(lineseg `vertsize` = 글자 크기, `spacing` = 나머지). 셀·캡션 맨 끝 줄은 줄 간격 몫을 높이에 넣지 않는다. 한양신명조 등 한글 글꼴의 빈칸은 글자 크기의 약 절반.
- 셀 안 문단에 매단 개체의 '문단 기준' 위치는 셀이 아니라 표를 담은 바깥 문단의 왼쪽 위에서 잰다.
- 개요 번호는 앞 구역에서 이어 센다. 구역 중간에서 새로 시작하려면 그 구역의 개요 번호 모양 `hh:numbering@start`를 정한다(같은 구역 안에서는 새로 시작 못 함).
- `version.xml`이 사용자 한글보다 높으면 열 때 경고 창이 뜬다 → 사용자 한글 버전 것을 쓴다.

## 7. 뼈대 코드

```python
import zipfile, copy
from lxml import etree
NS = {"hp": "http://www.hancom.co.kr/hwpml/2011/paragraph", "hh": "http://www.hancom.co.kr/hwpml/2011/head"}
src, dst = "원본.hwpx", "원본_수정본.hwpx"          # 원본은 덮어쓰지 않는다
zin = zipfile.ZipFile(src)
sec = etree.fromstring(zin.read("Contents/section0.xml"))
for p in sec.iter(f"{{{NS['hp']}}}p"):
    ...                                              # 서식 바꾸기(글자는 그대로)
    for ls in p.findall("hp:linesegarray", NS):      # 바꾼 문단은 줄 배치 캐시 삭제
        p.remove(ls)
with zipfile.ZipFile(dst, "w") as zout:
    zout.writestr(zipfile.ZipInfo("mimetype"), zin.read("mimetype"), compress_type=zipfile.ZIP_STORED)
    for item in zin.infolist():
        if item.filename == "mimetype":
            continue
        data = zin.read(item.filename)
        if item.filename == "Contents/section0.xml":
            data = etree.tostring(sec, xml_declaration=True, encoding="UTF-8", standalone=True)
        zout.writestr(item.filename, data, compress_type=zipfile.ZIP_DEFLATED)
```

다 만든 뒤 확인: `zipfile.testzip()`가 None, 모든 XML이 파싱됨, content.hpf의 BinData 항목이 다 있음, 원고와 결과의 글자 비교(엔진 `verify`가 이 검사를 한다).
